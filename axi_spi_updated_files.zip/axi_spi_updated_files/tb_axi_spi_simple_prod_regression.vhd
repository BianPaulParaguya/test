library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Production-oriented regression testbench for the updated AXI-to-SPI RTL.
--
-- This testbench is intended for the production-fix versions of:
--   1. axi4_lite_interface_v1_0.vhd
--   2. spi_peripheral.vhd
--   3. axi_spi_simple.vhd
--
-- It intentionally re-enables the tests that the compatible v3 testbench
-- avoided, including delayed AXI RREADY/BREADY and safe SPRF polling.

entity tb_axi_spi_simple_prod_regression is
end tb_axi_spi_simple_prod_regression;

architecture sim of tb_axi_spi_simple_prod_regression is

    constant CLK_PERIOD : time := 10 ns;

    -- AXI register offsets
    constant REG_TX_RX  : std_logic_vector(31 downto 0) := x"00000000";
    constant REG_STATUS : std_logic_vector(31 downto 0) := x"00000004";
    constant REG_CTRL   : std_logic_vector(31 downto 0) := x"00000008";
    constant REG_GPIO   : std_logic_vector(31 downto 0) := x"0000000C";

    -- SPI control register bits
    constant CTRL_CPHA      : integer := 16;
    constant CTRL_CPOL      : integer := 17;
    constant CTRL_LOOPBACK  : integer := 18;
    constant CTRL_LSBF      : integer := 19;

    constant AXI_TIMEOUT_CYCLES : integer := 3000;
    constant SPI_TIMEOUT_CYCLES : integer := 12000;

    type byte_array_t is array (natural range <>) of std_logic_vector(7 downto 0);
    constant LOOPBACK_BYTES : byte_array_t(0 to 7) := (
        x"00", x"FF", x"A5", x"5A", x"96", x"69", x"C3", x"3C"
    );
    constant EXTERNAL_BYTES : byte_array_t(0 to 3) := (
        x"3C", x"A7", x"81", x"7E"
    );

    signal saxi_aclk    : std_logic := '0';
    signal saxi_aresetn : std_logic := '0';

    signal saxi_awaddr  : std_logic_vector(31 downto 0) := (others => '0');
    signal saxi_awprot  : std_logic_vector(2 downto 0)  := (others => '0');
    signal saxi_awvalid : std_logic := '0';
    signal saxi_awready : std_logic;

    signal saxi_wdata   : std_logic_vector(31 downto 0) := (others => '0');
    signal saxi_wstrb   : std_logic_vector(3 downto 0)  := (others => '0');
    signal saxi_wvalid  : std_logic := '0';
    signal saxi_wready  : std_logic;

    signal saxi_bresp   : std_logic_vector(1 downto 0);
    signal saxi_bvalid  : std_logic;
    signal saxi_bready  : std_logic := '0';

    signal saxi_araddr  : std_logic_vector(31 downto 0) := (others => '0');
    signal saxi_arprot  : std_logic_vector(2 downto 0)  := (others => '0');
    signal saxi_arvalid : std_logic := '0';
    signal saxi_arready : std_logic;

    signal saxi_rdata   : std_logic_vector(31 downto 0);
    signal saxi_rresp   : std_logic_vector(1 downto 0);
    signal saxi_rvalid  : std_logic;
    signal saxi_rready  : std_logic := '0';

    signal mosi : std_logic;
    signal miso : std_logic := '0';
    signal ss   : std_logic;
    signal ssn  : std_logic;
    signal sclk : std_logic;
    signal gpo  : std_logic_vector(31 downto 0);

    -- Testbench-controlled SPI slave settings. These mirror the control word
    -- written into the DUT so the fake slave uses the same SPI mode.
    signal tb_cpol      : std_logic := '0';
    signal tb_cpha      : std_logic := '0';
    signal tb_lsb_first : std_logic := '0';
    signal tb_miso_byte : std_logic_vector(7 downto 0) := x"3C";

    -- What the fake external SPI slave sampled on MOSI during the last transfer.
    signal slave_rx_byte  : std_logic_vector(7 downto 0) := (others => '0');
    signal slave_rx_valid : std_logic := '0';

    function sl_from_int(i : integer) return std_logic is
    begin
        if i = 0 then
            return '0';
        else
            return '1';
        end if;
    end function;

begin

    --------------------------------------------------------------------------
    -- Clock generation
    --------------------------------------------------------------------------
    clk_gen : process
    begin
        while true loop
            saxi_aclk <= '0';
            wait for CLK_PERIOD / 2;
            saxi_aclk <= '1';
            wait for CLK_PERIOD / 2;
        end loop;
    end process;

    --------------------------------------------------------------------------
    -- Mode-aware fake SPI slave.
    --
    -- This slave drives tb_miso_byte on MISO and samples MOSI using the same
    -- CPOL/CPHA/LSB-first settings being tested. This verifies both directions
    -- of the SPI bus.
    --------------------------------------------------------------------------
    spi_slave_model : process
        variable tx_bit_pos    : integer := 7;
        variable rx_bit_count  : integer := 0;
        variable rx_temp       : std_logic_vector(7 downto 0) := (others => '0');
        variable tx_started    : boolean := false;
        variable sample_edge   : boolean := false;
        variable update_edge   : boolean := false;
        variable leading_edge  : boolean := false;
        variable trailing_edge : boolean := false;
    begin
        miso <= '0';
        slave_rx_byte  <= (others => '0');
        slave_rx_valid <= '0';

        wait until saxi_aresetn = '1';

        loop
            wait until ssn = '0';

            rx_temp      := (others => '0');
            rx_bit_count := 0;
            slave_rx_valid <= '0';

            if tb_lsb_first = '1' then
                tx_bit_pos := 0;
            else
                tx_bit_pos := 7;
            end if;

            -- CPHA=0 requires the first MISO bit valid before the first sample.
            -- CPHA=1 updates MISO on the first leading edge.
            if tb_cpha = '0' then
                miso <= tb_miso_byte(tx_bit_pos);
                tx_started := true;
            else
                miso <= '0';
                tx_started := false;
            end if;

            while ssn = '0' loop
                wait on sclk, ssn;

                if ssn = '1' then
                    exit;
                end if;

                leading_edge := false;
                trailing_edge := false;

                if tb_cpol = '0' then
                    if rising_edge(sclk) then
                        leading_edge := true;
                    elsif falling_edge(sclk) then
                        trailing_edge := true;
                    end if;
                else
                    if falling_edge(sclk) then
                        leading_edge := true;
                    elsif rising_edge(sclk) then
                        trailing_edge := true;
                    end if;
                end if;

                if tb_cpha = '0' then
                    sample_edge := leading_edge;
                    update_edge := trailing_edge;
                else
                    sample_edge := trailing_edge;
                    update_edge := leading_edge;
                end if;

                -- Slave shifts out MISO on the mode-specific update edge.
                if update_edge then
                    if tx_started = false then
                        miso <= tb_miso_byte(tx_bit_pos);
                        tx_started := true;
                    else
                        if tb_lsb_first = '1' then
                            if tx_bit_pos < 7 then
                                tx_bit_pos := tx_bit_pos + 1;
                            end if;
                        else
                            if tx_bit_pos > 0 then
                                tx_bit_pos := tx_bit_pos - 1;
                            end if;
                        end if;
                        miso <= tb_miso_byte(tx_bit_pos);
                    end if;
                end if;

                -- Slave samples MOSI on the mode-specific sample edge.
                if sample_edge then
                    wait for 1 ns;

                    if rx_bit_count < 8 then
                        if tb_lsb_first = '1' then
                            rx_temp(rx_bit_count) := mosi;
                        else
                            rx_temp(7 - rx_bit_count) := mosi;
                        end if;

                        if rx_bit_count = 7 then
                            slave_rx_byte  <= rx_temp;
                            slave_rx_valid <= '1';
                        end if;

                        rx_bit_count := rx_bit_count + 1;
                    end if;
                end if;
            end loop;

            miso <= '0';
        end loop;
    end process;

    --------------------------------------------------------------------------
    -- DUT
    --------------------------------------------------------------------------
    dut : entity work.axi_spi_simple
        generic map (
            ACTIVE_LOW_SS   => true,
            GPIO_WIDTH      => 32,
            USE_GPIO        => true,
            SAXI_DATA_WIDTH => 32,
            SAXI_ADDR_WIDTH => 2
        )
        port map (
            mosi => mosi,
            ss   => ss,
            ssn  => ssn,
            sclk => sclk,
            miso => miso,
            gpo  => gpo,

            saxi_aclk    => saxi_aclk,
            saxi_aresetn => saxi_aresetn,

            saxi_awaddr  => saxi_awaddr,
            saxi_awprot  => saxi_awprot,
            saxi_awvalid => saxi_awvalid,
            saxi_awready => saxi_awready,

            saxi_wdata   => saxi_wdata,
            saxi_wstrb   => saxi_wstrb,
            saxi_wvalid  => saxi_wvalid,
            saxi_wready  => saxi_wready,

            saxi_bresp   => saxi_bresp,
            saxi_bvalid  => saxi_bvalid,
            saxi_bready  => saxi_bready,

            saxi_araddr  => saxi_araddr,
            saxi_arprot  => saxi_arprot,
            saxi_arvalid => saxi_arvalid,
            saxi_arready => saxi_arready,

            saxi_rdata   => saxi_rdata,
            saxi_rresp   => saxi_rresp,
            saxi_rvalid  => saxi_rvalid,
            saxi_rready  => saxi_rready
        );

    --------------------------------------------------------------------------
    -- Main regression sequence
    --------------------------------------------------------------------------
    stim : process
        variable rd         : std_logic_vector(31 downto 0);
        variable ctrl_word  : std_logic_vector(31 downto 0);
        variable cpol_val   : std_logic;
        variable cpha_val   : std_logic;
        variable fail_count : integer := 0;

        procedure check(
            constant condition : in boolean;
            constant message   : in string
        ) is
        begin
            if not condition then
                fail_count := fail_count + 1;
                report "FAIL: " & message severity error;
            end if;
        end procedure;

        ----------------------------------------------------------------------
        -- AXI4-Lite write helper. This models a normal master where AWVALID,
        -- WVALID, and BREADY are asserted together.
        ----------------------------------------------------------------------
        procedure write_reg(
            constant addr : in std_logic_vector(31 downto 0);
            constant data : in std_logic_vector(31 downto 0);
            constant strb : in std_logic_vector(3 downto 0) := "1111"
        ) is
            variable aw_done : boolean := false;
            variable w_done  : boolean := false;
            variable timeout : integer := 0;
        begin
            saxi_awaddr  <= addr;
            saxi_wdata   <= data;
            saxi_wstrb   <= strb;
            saxi_awvalid <= '1';
            saxi_wvalid  <= '1';
            saxi_bready  <= '1';

            while not (aw_done and w_done) loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI WRITE TIMEOUT: AW/W handshake did not complete" severity failure;
                end if;

                if saxi_awvalid = '1' and saxi_awready = '1' then
                    aw_done := true;
                end if;

                if saxi_wvalid = '1' and saxi_wready = '1' then
                    w_done := true;
                end if;

                wait for 1 ns;
                if aw_done then
                    saxi_awvalid <= '0';
                end if;
                if w_done then
                    saxi_wvalid <= '0';
                end if;
            end loop;

            timeout := 0;
            loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI WRITE TIMEOUT: BVALID was never asserted" severity failure;
                end if;

                if saxi_bvalid = '1' then
                    check(saxi_bresp = "00", "AXI WRITE BRESP was not OKAY");
                    exit;
                end if;
            end loop;

            wait for 1 ns;
            saxi_bready <= '0';
            saxi_awaddr <= (others => '0');
            saxi_wdata  <= (others => '0');
            saxi_wstrb  <= (others => '0');
        end procedure;

        ----------------------------------------------------------------------
        -- AXI4-Lite read helper. This models a normal master where RREADY is
        -- asserted before RVALID arrives.
        ----------------------------------------------------------------------
        procedure read_reg(
            constant addr : in std_logic_vector(31 downto 0);
            variable data : out std_logic_vector(31 downto 0)
        ) is
            variable ar_done : boolean := false;
            variable timeout : integer := 0;
        begin
            saxi_araddr  <= addr;
            saxi_arvalid <= '1';
            saxi_rready  <= '1';

            while not ar_done loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI READ TIMEOUT: ARREADY was never asserted" severity failure;
                end if;

                if saxi_arvalid = '1' and saxi_arready = '1' then
                    ar_done := true;
                end if;

                wait for 1 ns;
                if ar_done then
                    saxi_arvalid <= '0';
                end if;
            end loop;

            timeout := 0;
            loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI READ TIMEOUT: RVALID was never asserted" severity failure;
                end if;

                if saxi_rvalid = '1' then
                    data := saxi_rdata;
                    check(saxi_rresp = "00", "AXI READ RRESP was not OKAY");
                    exit;
                end if;
            end loop;

            wait for 1 ns;
            saxi_rready <= '0';
            saxi_araddr <= (others => '0');
        end procedure;

        ----------------------------------------------------------------------
        -- AXI write with intentional AW/W channel skew.
        -- lead_select = 'A': AWVALID leads WVALID.
        -- lead_select = 'W': WVALID leads AWVALID.
        ----------------------------------------------------------------------
        procedure axi_write_skewed(
            constant addr        : in std_logic_vector(31 downto 0);
            constant data        : in std_logic_vector(31 downto 0);
            constant strb        : in std_logic_vector(3 downto 0);
            constant lead_select : in character;
            constant skew_cycles : in integer
        ) is
            variable aw_done : boolean := false;
            variable w_done  : boolean := false;
            variable timeout : integer := 0;
        begin
            saxi_awaddr  <= addr;
            saxi_wdata   <= data;
            saxi_wstrb   <= strb;
            saxi_bready  <= '1';

            if lead_select = 'A' then
                saxi_awvalid <= '1';
                saxi_wvalid  <= '0';
            else
                saxi_awvalid <= '0';
                saxi_wvalid  <= '1';
            end if;

            -- Let the leading channel be accepted first.  If it handshakes
            -- during the skew window, deassert that VALID before presenting
            -- the other channel.  This models a legal AXI master instead of
            -- holding a completed VALID high forever.
            for i in 1 to skew_cycles loop
                wait until rising_edge(saxi_aclk);

                if saxi_awvalid = '1' and saxi_awready = '1' then
                    aw_done := true;
                end if;

                if saxi_wvalid = '1' and saxi_wready = '1' then
                    w_done := true;
                end if;

                wait for 1 ns;

                if aw_done then
                    saxi_awvalid <= '0';
                end if;

                if w_done then
                    saxi_wvalid <= '0';
                end if;
            end loop;

            if not aw_done then
                saxi_awvalid <= '1';
            end if;

            if not w_done then
                saxi_wvalid <= '1';
            end if;

            while not (aw_done and w_done) loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI SKEWED WRITE TIMEOUT: AW/W handshake did not complete" severity failure;
                end if;

                if saxi_awvalid = '1' and saxi_awready = '1' then
                    aw_done := true;
                end if;

                if saxi_wvalid = '1' and saxi_wready = '1' then
                    w_done := true;
                end if;

                wait for 1 ns;
                if aw_done then
                    saxi_awvalid <= '0';
                end if;
                if w_done then
                    saxi_wvalid <= '0';
                end if;
            end loop;

            timeout := 0;
            loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI SKEWED WRITE TIMEOUT: BVALID was never asserted" severity failure;
                end if;

                if saxi_bvalid = '1' then
                    check(saxi_bresp = "00", "AXI SKEWED WRITE BRESP was not OKAY");
                    exit;
                end if;
            end loop;

            wait for 1 ns;
            saxi_bready <= '0';
            saxi_awaddr <= (others => '0');
            saxi_wdata  <= (others => '0');
            saxi_wstrb  <= (others => '0');
        end procedure;

        ----------------------------------------------------------------------
        -- AXI write where BREADY is intentionally delayed. The updated AXI RTL
        -- should hold BVALID/BRESP until the master accepts the response.
        ----------------------------------------------------------------------
        procedure axi_write_delayed_bready(
            constant addr : in std_logic_vector(31 downto 0);
            constant data : in std_logic_vector(31 downto 0);
            constant strb : in std_logic_vector(3 downto 0)
        ) is
            variable aw_done : boolean := false;
            variable w_done  : boolean := false;
            variable timeout : integer := 0;
        begin
            saxi_awaddr  <= addr;
            saxi_wdata   <= data;
            saxi_wstrb   <= strb;
            saxi_awvalid <= '1';
            saxi_wvalid  <= '1';
            saxi_bready  <= '0';

            while not (aw_done and w_done) loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI DELAYED-BREADY WRITE TIMEOUT: AW/W handshake did not complete" severity failure;
                end if;

                if saxi_awvalid = '1' and saxi_awready = '1' then
                    aw_done := true;
                end if;

                if saxi_wvalid = '1' and saxi_wready = '1' then
                    w_done := true;
                end if;

                wait for 1 ns;
                if aw_done then
                    saxi_awvalid <= '0';
                end if;
                if w_done then
                    saxi_wvalid <= '0';
                end if;
            end loop;

            timeout := 0;
            loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI DELAYED-BREADY WRITE TIMEOUT: BVALID was never asserted" severity failure;
                end if;

                if saxi_bvalid = '1' then
                    exit;
                end if;
            end loop;

            for i in 1 to 5 loop
                wait until rising_edge(saxi_aclk);
                check(saxi_bvalid = '1', "BVALID was not held while BREADY was low");
                check(saxi_bresp = "00", "BRESP changed or was not OKAY while BREADY was low");
            end loop;

            saxi_bready <= '1';
            wait until rising_edge(saxi_aclk);
            wait for 1 ns;
            saxi_bready <= '0';
        end procedure;

        ----------------------------------------------------------------------
        -- AXI read where RREADY is intentionally delayed. The updated AXI RTL
        -- should hold RVALID/RDATA stable until the master accepts the data.
        ----------------------------------------------------------------------
        procedure axi_read_delayed_rready(
            constant addr : in std_logic_vector(31 downto 0);
            variable data : out std_logic_vector(31 downto 0)
        ) is
            variable ar_done   : boolean := false;
            variable timeout   : integer := 0;
            variable held_data : std_logic_vector(31 downto 0);
        begin
            saxi_araddr  <= addr;
            saxi_arvalid <= '1';
            saxi_rready  <= '0';

            while not ar_done loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI DELAYED-RREADY READ TIMEOUT: ARREADY was never asserted" severity failure;
                end if;

                if saxi_arvalid = '1' and saxi_arready = '1' then
                    ar_done := true;
                end if;

                wait for 1 ns;
                if ar_done then
                    saxi_arvalid <= '0';
                end if;
            end loop;

            timeout := 0;
            loop
                wait until rising_edge(saxi_aclk);
                timeout := timeout + 1;
                if timeout >= AXI_TIMEOUT_CYCLES then
                    report "AXI DELAYED-RREADY READ TIMEOUT: RVALID was never asserted" severity failure;
                end if;

                if saxi_rvalid = '1' then
                    held_data := saxi_rdata;
                    exit;
                end if;
            end loop;

            for i in 1 to 5 loop
                wait until rising_edge(saxi_aclk);
                check(saxi_rvalid = '1', "RVALID was not held while RREADY was low");
                check(saxi_rdata = held_data, "RDATA changed while RVALID was held and RREADY was low");
                check(saxi_rresp = "00", "RRESP was not OKAY while RREADY was low");
            end loop;

            data := held_data;
            saxi_rready <= '1';
            wait until rising_edge(saxi_aclk);
            wait for 1 ns;
            saxi_rready <= '0';
            saxi_araddr <= (others => '0');
        end procedure;

        procedure wait_for_sprf(variable status_data : out std_logic_vector(31 downto 0)) is
            variable got_sprf : boolean := false;
        begin
            for i in 0 to SPI_TIMEOUT_CYCLES loop
                read_reg(REG_STATUS, status_data);

                if status_data(1) = '1' then
                    got_sprf := true;
                    exit;
                end if;

                wait until rising_edge(saxi_aclk);
            end loop;

            check(got_sprf, "SPI receive buffer full flag never asserted");
        end procedure;

        procedure wait_for_idle_and_tx_empty(variable status_data : out std_logic_vector(31 downto 0)) is
            variable idle_seen : boolean := false;
        begin
            for i in 0 to SPI_TIMEOUT_CYCLES loop
                read_reg(REG_STATUS, status_data);

                if status_data(0) = '1' and status_data(2) = '0' then
                    idle_seen := true;
                    exit;
                end if;

                wait until rising_edge(saxi_aclk);
            end loop;

            check(idle_seen, "SPI did not return to idle with transmit-empty set");
        end procedure;

        procedure assert_no_spi_activity(constant cycles_to_watch : in integer) is
            variable last_ssn  : std_logic;
            variable last_sclk : std_logic;
        begin
            last_ssn  := ssn;
            last_sclk := sclk;

            for i in 1 to cycles_to_watch loop
                wait until rising_edge(saxi_aclk);
                wait for 1 ns;
                check(ssn = last_ssn,  "SSN changed during a non-SPI register operation");
                check(sclk = last_sclk, "SCLK changed during a non-SPI register operation");
            end loop;
        end procedure;

        procedure assert_no_chip_select_activity(constant cycles_to_watch : in integer) is
        begin
            -- Control-register writes may legally change idle SCLK through CPOL.
            -- For CTRL writes, only check that no SPI transaction starts.
            for i in 1 to cycles_to_watch loop
                wait until rising_edge(saxi_aclk);
                wait for 1 ns;
                check(ssn = '1', "SSN asserted during a non-transfer control operation");
            end loop;
        end procedure;

        procedure wait_until_ssn_low is
            variable seen : boolean := false;
        begin
            for i in 0 to SPI_TIMEOUT_CYCLES loop
                wait until rising_edge(saxi_aclk);
                wait for 1 ns;
                if ssn = '0' then
                    seen := true;
                    exit;
                end if;
            end loop;
            check(seen, "SSN did not assert low during SPI transfer");
        end procedure;

        procedure check_spi_bus_activity is
            variable saw_ss_low : boolean := false;
            variable edge_count : integer := 0;
            variable last_sclk  : std_logic;
        begin
            last_sclk := sclk;

            for i in 0 to SPI_TIMEOUT_CYCLES loop
                wait until rising_edge(saxi_aclk);
                wait for 1 ns;

                if ssn = '0' then
                    saw_ss_low := true;
                end if;

                if sclk /= last_sclk then
                    edge_count := edge_count + 1;
                    last_sclk := sclk;
                end if;

                if saw_ss_low and ssn = '1' and edge_count >= 16 then
                    exit;
                end if;
            end loop;

            check(saw_ss_low, "SSN did not assert during SPI transfer");
            check(edge_count >= 16, "SCLK did not toggle enough for an 8-bit SPI transfer");
            check(ssn = '1', "SSN did not deassert after SPI transfer");
        end procedure;

        procedure configure_spi(
            constant baud_divisor : in std_logic_vector(15 downto 0);
            constant cpol         : in std_logic;
            constant cpha         : in std_logic;
            constant loopback     : in std_logic;
            constant lsb_first    : in std_logic
        ) is
            variable rd_local : std_logic_vector(31 downto 0);
            variable cw       : std_logic_vector(31 downto 0);
        begin
            tb_cpol      <= cpol;
            tb_cpha      <= cpha;
            tb_lsb_first <= lsb_first;

            cw := (others => '0');
            cw(15 downto 0) := baud_divisor;
            cw(CTRL_CPOL) := cpol;
            cw(CTRL_CPHA) := cpha;
            cw(CTRL_LOOPBACK) := loopback;
            cw(CTRL_LSBF) := lsb_first;

            write_reg(REG_CTRL, cw, "1111");
            assert_no_chip_select_activity(5);

            read_reg(REG_CTRL, rd_local);
            check(rd_local(19 downto 0) = cw(19 downto 0), "Control register readback mismatch");
        end procedure;

        procedure run_spi_transfer(
            constant test_name    : in string;
            constant tx_byte      : in std_logic_vector(7 downto 0);
            constant expected_rx  : in std_logic_vector(7 downto 0);
            constant miso_byte    : in std_logic_vector(7 downto 0);
            constant baud_divisor : in std_logic_vector(15 downto 0);
            constant cpol         : in std_logic;
            constant cpha         : in std_logic;
            constant loopback     : in std_logic;
            constant lsb_first    : in std_logic
        ) is
            variable status_local : std_logic_vector(31 downto 0);
            variable rx_word      : std_logic_vector(31 downto 0);
        begin
            report "Running SPI transfer: " & test_name severity note;

            tb_miso_byte <= miso_byte;
            configure_spi(baud_divisor, cpol, cpha, loopback, lsb_first);

            write_reg(REG_TX_RX, x"000000" & tx_byte, "0001");
            check_spi_bus_activity;

            -- Updated production RTL should make STATUS polling safe.
            wait_for_sprf(status_local);
            wait_for_idle_and_tx_empty(status_local);

            check(slave_rx_valid = '1', "external SPI slave did not sample a full MOSI byte");
            check(slave_rx_byte = tx_byte, "external SPI slave sampled wrong MOSI byte");

            read_reg(REG_TX_RX, rx_word);
            check(rx_word(7 downto 0) = expected_rx, "SPI RX data mismatch");

            -- Updated production RTL should clear SPRF when RX data is consumed.
            read_reg(REG_STATUS, status_local);
            check(status_local(1) = '0', "SPRF did not clear after RX data register read");
            check(status_local(0) = '1', "SPTEF should be 1 after completed transfer");
            check(status_local(2) = '0', "SPI busy should be 0 after completed transfer");
        end procedure;

        procedure run_status_polling_clear_test is
            variable status_local : std_logic_vector(31 downto 0);
            variable rx_word      : std_logic_vector(31 downto 0);
        begin
            report "Testing safe SPRF polling and RX-read clear behavior..." severity note;

            tb_miso_byte <= x"A7";
            configure_spi(x"0008", '0', '0', '0', '0');
            write_reg(REG_TX_RX, x"00000055", "0001");
            check_spi_bus_activity;

            wait_for_sprf(status_local);
            check(status_local(1) = '1', "SPRF was not seen after external SPI transfer");

            read_reg(REG_STATUS, status_local);
            check(status_local(1) = '1', "STATUS read incorrectly cleared SPRF on first poll");

            read_reg(REG_STATUS, status_local);
            check(status_local(1) = '1', "STATUS read incorrectly cleared SPRF on second poll");

            read_reg(REG_TX_RX, rx_word);
            check(rx_word(7 downto 0) = x"A7", "RX data register did not return expected byte before clearing SPRF");

            read_reg(REG_STATUS, status_local);
            check(status_local(1) = '0', "SPRF did not clear after RX data register read");
        end procedure;

        procedure run_busy_status_test is
            variable status_local : std_logic_vector(31 downto 0);
            variable rx_word      : std_logic_vector(31 downto 0);
        begin
            report "Testing busy status during active SPI transaction..." severity note;

            configure_spi(x"0020", '0', '0', '1', '0');
            write_reg(REG_TX_RX, x"0000005A", "0001");

            wait_until_ssn_low;
            read_reg(REG_STATUS, status_local);
            check(status_local(2) = '1', "SPI busy bit was not high while SSN was active");

            wait_for_sprf(status_local);
            wait_for_idle_and_tx_empty(status_local);
            read_reg(REG_TX_RX, rx_word);
            check(rx_word(7 downto 0) = x"5A", "Busy-status test RX data mismatch");
        end procedure;

    begin
        report "Applying reset..." severity note;

        saxi_aresetn <= '0';
        wait for 10 * CLK_PERIOD;

        saxi_aresetn <= '1';
        wait for 5 * CLK_PERIOD;

        ----------------------------------------------------------------------
        -- Reset checks
        ----------------------------------------------------------------------
        report "Checking reset status and idle pins..." severity note;

        read_reg(REG_STATUS, rd);
        check(rd(0) = '1', "SPTEF should be 1 after reset");
        check(rd(1) = '0', "SPRF should be 0 after reset");
        check(rd(2) = '0', "SPI busy should be 0 after reset");
        check(ssn = '1', "active-low SSN should be inactive/high after reset");
        check(ss = '0', "active-high SS should be inactive/low after reset");

        ----------------------------------------------------------------------
        -- GPIO, write strobes, and control-register isolation checks
        ----------------------------------------------------------------------
        report "Testing GPIO register, readback, byte strobes, and CTRL isolation..." severity note;

        write_reg(REG_GPIO, x"00000000", "1111");
        assert_no_spi_activity(5);

        write_reg(REG_GPIO, x"000000AA", "0001");
        read_reg(REG_GPIO, rd);
        check(rd = x"000000AA" and gpo = x"000000AA", "GPIO byte strobe 0001 failed");

        write_reg(REG_GPIO, x"0000BB00", "0010");
        read_reg(REG_GPIO, rd);
        check(rd = x"0000BBAA" and gpo = x"0000BBAA", "GPIO byte strobe 0010 failed");

        write_reg(REG_GPIO, x"00CC0000", "0100");
        read_reg(REG_GPIO, rd);
        check(rd = x"00CCBBAA" and gpo = x"00CCBBAA", "GPIO byte strobe 0100 failed");

        write_reg(REG_GPIO, x"DD000000", "1000");
        read_reg(REG_GPIO, rd);
        check(rd = x"DDCCBBAA" and gpo = x"DDCCBBAA", "GPIO byte strobe 1000 failed");

        -- Production fix check: writing the high byte of CTRL must not corrupt GPIO.
        write_reg(REG_CTRL, x"AA000000", "1000");
        read_reg(REG_GPIO, rd);
        check(rd = x"DDCCBBAA" and gpo = x"DDCCBBAA", "CTRL high-byte write corrupted GPIO register");

        ----------------------------------------------------------------------
        -- AXI robustness checks
        ----------------------------------------------------------------------
        report "Testing AXI write/read robustness cases..." severity note;

        axi_write_skewed(REG_GPIO, x"11223344", "1111", 'A', 4);
        read_reg(REG_GPIO, rd);
        check(rd = x"11223344" and gpo = x"11223344", "AXI AW-before-W write failed");

        axi_write_skewed(REG_GPIO, x"55667788", "1111", 'W', 4);
        read_reg(REG_GPIO, rd);
        check(rd = x"55667788" and gpo = x"55667788", "AXI W-before-AW write failed");

        axi_write_delayed_bready(REG_GPIO, x"CAFEBABE", "1111");
        read_reg(REG_GPIO, rd);
        check(rd = x"CAFEBABE" and gpo = x"CAFEBABE", "AXI delayed-BREADY write failed");

        write_reg(REG_GPIO, x"12345678", "1111");
        axi_read_delayed_rready(REG_GPIO, rd);
        check(rd = x"12345678", "AXI delayed-RREADY read returned wrong data");

        ----------------------------------------------------------------------
        -- Non-transfer writes and SCLK idle-level checks
        ----------------------------------------------------------------------
        report "Testing no accidental SPI start and CPOL idle SCLK behavior..." severity note;

        write_reg(REG_TX_RX, x"0000AA00", "0010");
        assert_no_spi_activity(10);
        read_reg(REG_STATUS, rd);
        check(rd(0) = '1', "Upper-byte TX/RX write should not mark transmit buffer non-empty");

        configure_spi(x"0004", '0', '0', '1', '0');
        wait for 5 * CLK_PERIOD;
        check(ssn = '1' and sclk = '0', "CPOL=0 should leave SPI idle with SSN high and SCLK low");

        configure_spi(x"0004", '1', '0', '1', '0');
        wait for 5 * CLK_PERIOD;
        check(ssn = '1' and sclk = '1', "CPOL=1 should leave SPI idle with SSN high and SCLK high");

        ----------------------------------------------------------------------
        -- Production-fix specific tests
        ----------------------------------------------------------------------
        run_status_polling_clear_test;
        run_busy_status_test;

        ----------------------------------------------------------------------
        -- Internal loopback coverage across modes, data, and both bit orders.
        -- Expected RX = transmitted byte.
        ----------------------------------------------------------------------
        report "Testing SPI internal loopback across CPOL/CPHA modes, MSB-first..." severity note;

        for cpol_i in 0 to 1 loop
            for cpha_i in 0 to 1 loop
                cpol_val := sl_from_int(cpol_i);
                cpha_val := sl_from_int(cpha_i);

                for i in LOOPBACK_BYTES'range loop
                    run_spi_transfer(
                        "loopback MSB-first CPOL/CPHA sweep",
                        LOOPBACK_BYTES(i),
                        LOOPBACK_BYTES(i),
                        x"00",
                        x"0004",
                        cpol_val,
                        cpha_val,
                        '1',
                        '0'
                    );
                end loop;
            end loop;
        end loop;

        report "Testing SPI internal loopback across CPOL/CPHA modes, LSB-first..." severity note;

        for cpol_i in 0 to 1 loop
            for cpha_i in 0 to 1 loop
                cpol_val := sl_from_int(cpol_i);
                cpha_val := sl_from_int(cpha_i);

                for i in LOOPBACK_BYTES'range loop
                    run_spi_transfer(
                        "loopback LSB-first CPOL/CPHA sweep",
                        LOOPBACK_BYTES(i),
                        LOOPBACK_BYTES(i),
                        x"00",
                        x"0004",
                        cpol_val,
                        cpha_val,
                        '1',
                        '1'
                    );
                end loop;
            end loop;
        end loop;

        ----------------------------------------------------------------------
        -- External MISO coverage across modes and bit orders.
        -- Expected RX = byte driven by the mode-aware slave model.
        ----------------------------------------------------------------------
        report "Testing external MISO receive across CPOL/CPHA modes, MSB-first..." severity note;

        for cpol_i in 0 to 1 loop
            for cpha_i in 0 to 1 loop
                cpol_val := sl_from_int(cpol_i);
                cpha_val := sl_from_int(cpha_i);

                for i in EXTERNAL_BYTES'range loop
                    run_spi_transfer(
                        "external MISO MSB-first CPOL/CPHA sweep",
                        x"96",
                        EXTERNAL_BYTES(i),
                        EXTERNAL_BYTES(i),
                        x"0008",
                        cpol_val,
                        cpha_val,
                        '0',
                        '0'
                    );
                end loop;
            end loop;
        end loop;

        report "Testing external MISO receive across CPOL/CPHA modes, LSB-first..." severity note;

        for cpol_i in 0 to 1 loop
            for cpha_i in 0 to 1 loop
                cpol_val := sl_from_int(cpol_i);
                cpha_val := sl_from_int(cpha_i);

                for i in EXTERNAL_BYTES'range loop
                    run_spi_transfer(
                        "external MISO LSB-first CPOL/CPHA sweep",
                        x"69",
                        EXTERNAL_BYTES(i),
                        EXTERNAL_BYTES(i),
                        x"0008",
                        cpol_val,
                        cpha_val,
                        '0',
                        '1'
                    );
                end loop;
            end loop;
        end loop;

        ----------------------------------------------------------------------
        -- Back-to-back SPI transactions without long idle gaps.
        ----------------------------------------------------------------------
        report "Testing back-to-back SPI transfers..." severity note;

        for i in LOOPBACK_BYTES'range loop
            run_spi_transfer(
                "back-to-back loopback",
                LOOPBACK_BYTES(i),
                LOOPBACK_BYTES(i),
                x"00",
                x"0002",
                '0',
                '0',
                '1',
                '0'
            );
        end loop;

        ----------------------------------------------------------------------
        -- Final status check
        ----------------------------------------------------------------------
        report "Checking final idle status..." severity note;

        read_reg(REG_STATUS, rd);
        check(rd(0) = '1', "SPTEF should be 1 after final transfer");
        check(rd(1) = '0', "SPRF should be 0 after final RX read");
        check(rd(2) = '0', "SPI busy should be 0 after final transfer");
        check(ssn = '1', "SSN should be inactive/high at end of test");

        if fail_count = 0 then
            report "ALL PRODUCTION REGRESSION TESTS PASSED." severity note;
        else
            report "PRODUCTION REGRESSION FAILED. Total failed checks = " & integer'image(fail_count) severity failure;
        end if;

        wait;
    end process;

end sim;
