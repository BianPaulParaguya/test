AXI4-Lite to SPI Updated VHDL Files
===================================

Overview
--------

This project implements an AXI4-Lite controlled SPI master. The design allows a processor or AXI master to configure SPI settings, start SPI transfers, read received data, check status flags, and optionally drive GPIO outputs.

The design is split into three main RTL modules:

1. axi4_lite_interface_v1_0.vhd
2. spi_peripheral.vhd
3. axi_spi_simple.vhd

A production-oriented regression testbench is also included:

4. tb_axi_spi_simple_prod_regression.vhd


Compile Order
-------------

Compile the files in this order:

1. axi4_lite_interface_v1_0.vhd
2. spi_peripheral.vhd
3. axi_spi_simple.vhd
4. tb_axi_spi_simple_prod_regression.vhd

Simulation top:

tb_axi_spi_simple_prod_regression

Expected final passing message:

ALL PRODUCTION REGRESSION TESTS PASSED.

If failures occur, the testbench reports them and ends with a failed-check count.


Module Summary
==============


1. axi4_lite_interface_v1_0.vhd
--------------------------------

This module implements the AXI4-Lite slave interface.

Its job is to accept AXI4-Lite read and write transactions from an AXI master and convert them into simpler local register-control signals for the SPI peripheral.

It handles:

- AXI write address channel: AWVALID, AWREADY, AWADDR
- AXI write data channel: WVALID, WREADY, WDATA, WSTRB
- AXI write response channel: BVALID, BREADY, BRESP
- AXI read address channel: ARVALID, ARREADY, ARADDR
- AXI read data channel: RVALID, RREADY, RDATA, RRESP

The AXI interface outputs local signals such as:

- write_enable
- write_address
- write_data
- write_strobe
- read_enable
- read_address
- read_data

These local signals are used by spi_peripheral.vhd.

Purpose:

This module acts as the bridge between the AXI4-Lite bus and the internal SPI register block.


2. spi_peripheral.vhd
----------------------

This module implements the actual SPI peripheral logic.

It contains:

- TX/RX data register
- status register
- control register
- GPIO register
- SPI state machine
- baud-rate divider
- MOSI output logic
- MISO input logic
- chip-select logic
- SCLK generation
- receive-full and transmit-empty status flags

The main register map is:

0x00 - TX/RX data register
0x04 - STATUS register
0x08 - CONTROL register
0x0C - GPIO register

The status register includes:

bit 0 - SPTEF: SPI transmit empty flag
bit 1 - SPRF:  SPI receive buffer full flag
bit 2 - busy:  SPI transfer currently active

The control register includes:

bits 15 downto 0 - baud divisor
bit 16           - CPHA
bit 17           - CPOL
bit 18           - loopback enable
bit 19           - LSB-first enable

Purpose:

This module is the core of the SPI design. When software writes a byte to the TX/RX register, this module starts a SPI transaction, asserts chip select, generates SCLK, shifts data out on MOSI, samples MISO, stores the received byte, and updates status flags.


3. axi_spi_simple.vhd
----------------------

This is the top-level wrapper.

It instantiates:

- axi4_lite_interface_v1_0
- spi_peripheral

It connects the AXI4-Lite interface to the SPI peripheral through the internal local register signals.

Purpose:

This module ties the AXI bus interface and SPI peripheral together into one complete AXI-to-SPI bridge.

External ports include:

- saxi_aclk
- saxi_aresetn
- AXI4-Lite signals
- mosi
- miso
- sclk
- ss
- ssn
- gpo


4. tb_axi_spi_simple_prod_regression.vhd
-----------------------------------------

This is the updated production-oriented regression testbench.

It thoroughly tests the updated RTL modules, including the specific issues that were found during earlier testing.

It checks:

- reset behavior
- normal AXI reads and writes
- AXI delayed read handshake behavior
- AXI delayed write response behavior
- AW-before-W write ordering
- W-before-AW write ordering
- GPIO register readback
- GPIO byte strobes
- control register readback
- control register writes not corrupting GPIO
- SPI internal loopback
- SPI loopback in MSB-first mode
- SPI loopback in LSB-first mode
- external MISO receive
- MOSI transmit verification
- CPOL and CPHA SPI modes
- SCLK idle level
- SSN assertion and deassertion
- SPI busy status
- SPRF polling behavior
- SPRF clearing after RX data read
- back-to-back SPI transfers

Purpose:

This testbench verifies that the updated design behaves correctly under more realistic and production-relevant conditions.


Issues Found During Testing
===========================


1. AXI delayed read handshake failure
-------------------------------------

Failure observed:

AXI delayed read handshake test failed

What it meant:

The AXI testbench delayed RREADY to check whether the AXI slave would hold RVALID and keep RDATA stable until the master accepted the read data.

The original AXI read logic was designed around the simpler case where RREADY is already asserted during the read transaction.

Why it matters:

In a real AXI system, an AXI master or AXI interconnect may delay RREADY. A production-quality AXI4-Lite slave should handle that by holding the read response until the transfer completes.

Fix:

The AXI read channel was updated so that:

- RVALID stays asserted while RREADY = 0
- RDATA remains stable while waiting
- the read completes only when RVALID = 1 and RREADY = 1


2. AXI delayed write response issue
-----------------------------------

Related issue:

Delayed BREADY / write response backpressure

What it meant:

The testbench checked whether the AXI slave could hold BVALID until the AXI master asserted BREADY.

The earlier design assumed a simpler write response sequence where BREADY was already asserted.

Why it matters:

A real AXI master or interconnect can delay BREADY. The AXI slave should not drop or miss the write response.

Fix:

The AXI write channel was updated so that:

- AWVALID and WVALID can arrive independently
- the write is performed once both address and data are captured
- BVALID stays asserted until BREADY = 1

This makes the AXI write path more robust.


3. SPI receive buffer full flag never asserted
----------------------------------------------

Failure observed:

FAIL: SPI receive buffer full flag never asserted

What it meant:

The testbench was polling the status register waiting for SPRF = 1.

SPRF means:

SPI Receive Buffer Full

This flag should indicate that a SPI transfer completed and a received byte is available.

The earlier behavior allowed SPRF to be cleared by reading the status register. Because of that, repeated status polling could clear the flag before the testbench or software reliably observed it.

Why it matters:

Software commonly polls a status register waiting for a receive-full flag. If reading the status register clears the flag, software can accidentally miss the event.

Fix:

The SPRF clearing behavior was changed.

Updated behavior:

- Reading STATUS does not clear SPRF
- Reading RX data clears SPRF

This allows software to safely do:

1. Poll STATUS until SPRF = 1
2. Read RX data
3. SPRF clears after RX data is consumed


4. Internal loopback did not fully support LSB-first mode
---------------------------------------------------------

What it meant:

The original loopback path fed back bit 7 even when LSB-first mode was enabled.

That meant internal loopback was valid for MSB-first mode but not fully valid for LSB-first mode.

Why it matters:

If the control register supports LSB-first transfers, then loopback testing should reflect the same bit order that MOSI uses.

Fix:

The loopback path was updated so that:

- MSB-first loopback uses bit 7
- LSB-first loopback uses bit 0

Now internal loopback follows the selected bit order.


5. Control-register high-byte write typo
-----------------------------------------

Original issue:

The control-register high-byte write case affected reg3 instead of reg2.

What it meant:

A write intended for the upper byte of the control register could incorrectly modify the GPIO register.

Why it matters:

Control-register writes should not corrupt GPIO outputs or unrelated registers.

Fix:

The high-byte control-register write now correctly targets:

reg2(31 downto 24)

instead of:

reg3(31 downto 24)


6. ModelSim dataflow license warning
------------------------------------

Warning observed:

Warning: No extended dataflow license exists

What it meant:

This was a ModelSim/Questa GUI warning related to the extended Dataflow view.

Why it matters:

This was not a VHDL design failure and was not related to the AXI or SPI behavior.

Resolution:

The warning can be ignored for normal simulation, or the Dataflow view can be disabled in the simulator GUI.


Changes Made
============


axi4_lite_interface_v1_0.vhd
----------------------------

Changes made:

- Fixed multiple drivers on read_enable.
- Updated read-channel behavior to support delayed RREADY.
- Updated write-response behavior to support delayed BREADY.
- Allowed AXI write address and write data channels to be accepted independently.
- Added internal latching of read address, write address, write data, and write strobes.
- Ensured RVALID and RDATA remain stable until the read handshake completes.
- Ensured BVALID remains asserted until the write response handshake completes.

Result:

The AXI4-Lite interface is more robust and better suited for integration with a real AXI master or interconnect.


spi_peripheral.vhd
------------------

Changes made:

- Fixed typo in the control-register write case.
- Updated SPRF behavior so reading STATUS does not clear the receive-full flag.
- Updated SPRF behavior so reading RX data clears the receive-full flag.
- Updated internal loopback so LSB-first mode feeds back the correct bit.
- Preserved normal SPI state-machine behavior.
- Preserved baud-divisor-based SCLK generation.
- Preserved CPOL/CPHA support.
- Preserved GPIO behavior and byte-strobe support.

Result:

The SPI peripheral is safer for software polling and now supports internal loopback for both MSB-first and LSB-first behavior.


axi_spi_simple.vhd
------------------

Changes made:

- Kept functionally the same.
- Cleaned formatting.
- Kept the top-level connection between the AXI4-Lite interface and SPI peripheral.
- Ensured component declarations match the updated module interfaces.

Result:

The top-level wrapper connects the updated AXI interface and updated SPI peripheral into one complete AXI-to-SPI bridge.


tb_axi_spi_simple_prod_regression.vhd
-------------------------------------

Changes made:

- Added production-oriented regression testing.
- Added AXI delayed read handshake test.
- Added AXI delayed write response test.
- Added AW-before-W and W-before-AW tests.
- Added safe SPRF polling test.
- Added SPRF clear-on-RX-read test.
- Added internal loopback tests for MSB-first and LSB-first modes.
- Added external MISO tests across SPI modes.
- Added MOSI verification from the fake SPI slave.
- Added GPIO byte-strobe tests.
- Added control-register corruption check.
- Added CPOL idle-clock checks.
- Added back-to-back SPI transfer tests.
- Added failure counting so the final pass/fail result is trustworthy.

Result:

The testbench now verifies both the original SPI functionality and the production-level fixes added to the AXI and status-flag logic.


What Passing the Regression Means
=================================

If the production regression testbench completes with:

ALL PRODUCTION REGRESSION TESTS PASSED.

and there are no FAIL, ERROR, or severity error messages from the same run, then the design has passed the tested functional simulation requirements.

This means the following behavior is verified in simulation:

- reset and idle behavior
- normal AXI register access
- AXI read backpressure handling
- AXI write response backpressure handling
- GPIO output behavior
- GPIO byte strobes
- SPI control register configuration
- SPI clock generation
- chip-select behavior
- MOSI transmit behavior
- MISO receive behavior
- internal loopback
- MSB-first operation
- LSB-first operation
- external SPI receive
- status polling
- receive-full flag clearing
- back-to-back SPI transfers


Production Readiness Notes
==========================

Passing simulation does not by itself prove final hardware readiness.

Before production use, the design should still go through:

- synthesis
- implementation/place-and-route
- static timing analysis
- pin constraint review
- clock/reset constraint review
- hardware bring-up
- real SPI slave testing
- software driver testing

However, passing the production regression testbench provides strong functional evidence that the AXI-to-SPI bridge is ready to move forward into synthesis and hardware validation.


Summary
=======

The updated design fixes the main issues found during earlier testing:

- AXI delayed read handshake failure
- AXI delayed write response limitation
- SPRF polling issue
- LSB-first loopback issue
- control-register high-byte typo

The AXI4-Lite interface is now more robust, the SPI receive-full flag is safer for software polling, internal loopback supports both bit orders, and the regression testbench now verifies the design under more production-relevant scenarios.
