-- MIT License
--
-- Copyright (c) 2021 Douglas H. Summerville, Department of Electical and Computer Engineering, Binghamton University
--
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:
--
-- The above copyright notice and this permission notice shall be included in all
-- copies or substantial portions of the Software.
--
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
-- SOFTWARE.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity axi4_lite_interface_v1_0 is
    generic (
        DATA_BUS_IS_64_BITS: integer range 0 to 1 := 0; -- 0:32b, 1:64b
        ADDR_WIDTH : integer range 1 to 12 := 2;
        USE_WRITE_STROBES : boolean := false;
        SUBORDINATE_SYNCHRONOUS_READ_PORT: boolean := true
    );
    port (
        -- AXI4-Lite subordinate signals
        SAXI_ACLK     : in std_logic;
        SAXI_ARESETN  : in std_logic;

        SAXI_AWADDR   : in std_logic_vector(31 downto 0);
        SAXI_AWPROT   : in std_logic_vector(2 downto 0);
        SAXI_AWVALID  : in std_logic;
        SAXI_AWREADY  : out std_logic;

        SAXI_WDATA    : in std_logic_vector(32*(1+DATA_BUS_IS_64_BITS)-1 downto 0);
        SAXI_WSTRB    : in std_logic_vector((4*(1+DATA_BUS_IS_64_BITS))-1 downto 0);
        SAXI_WVALID   : in std_logic;
        SAXI_WREADY   : out std_logic;

        SAXI_BRESP    : out std_logic_vector(1 downto 0);
        SAXI_BVALID   : out std_logic;
        SAXI_BREADY   : in std_logic;

        SAXI_ARADDR   : in std_logic_vector(31 downto 0);
        SAXI_ARPROT   : in std_logic_vector(2 downto 0);
        SAXI_ARVALID  : in std_logic;
        SAXI_ARREADY  : out std_logic;

        SAXI_RDATA    : out std_logic_vector(32*(1+DATA_BUS_IS_64_BITS)-1 downto 0);
        SAXI_RRESP    : out std_logic_vector(1 downto 0);
        SAXI_RVALID   : out std_logic;
        SAXI_RREADY   : in std_logic;

        -- Subordinate interface
        read_address  : out std_logic_vector(ADDR_WIDTH-1 downto 0);
        write_address : out std_logic_vector(ADDR_WIDTH-1 downto 0);
        read_enable   : out std_logic;
        write_enable  : out std_logic;
        write_strobe  : out std_logic_vector((4*(1+DATA_BUS_IS_64_BITS))-1 downto 0);
        read_data     : in std_logic_vector(32*(1+DATA_BUS_IS_64_BITS)-1 downto 0);
        write_data    : out std_logic_vector(32*(1+DATA_BUS_IS_64_BITS)-1 downto 0);

        clk           : out std_logic;
        resetn        : out std_logic
    );
end axi4_lite_interface_v1_0;

architecture arch_imp of axi4_lite_interface_v1_0 is

    constant DATA_WIDTH   : integer := 32*(1+DATA_BUS_IS_64_BITS);
    constant STROBE_WIDTH : integer := 4*(1+DATA_BUS_IS_64_BITS);

    constant REG_ADDR_lsb : integer := 2*(1+DATA_BUS_IS_64_BITS);
    constant REG_ADDR_msb : integer := REG_ADDR_lsb + ADDR_WIDTH - 1;

    alias local_read_addr  : std_logic_vector(REG_ADDR_msb downto REG_ADDR_lsb) is SAXI_ARADDR(REG_ADDR_msb downto REG_ADDR_lsb);
    alias local_write_addr : std_logic_vector(REG_ADDR_msb downto REG_ADDR_lsb) is SAXI_AWADDR(REG_ADDR_msb downto REG_ADDR_lsb);

    -- AXI read channel registers
    type READ_STATE_TYPE is (RD_IDLE, RD_CAPTURE, RD_RESP);
    signal rd_state : READ_STATE_TYPE := RD_IDLE;

    signal arready : std_logic := '1';
    signal rvalid  : std_logic := '0';
    signal rdata   : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal rresp   : std_logic_vector(1 downto 0) := (others => '0');

    signal read_address_reg : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal read_enable_reg  : std_logic := '0';

    -- AXI write channel registers.  This implementation accepts AW and W
    -- independently, performs one subordinate write when both have arrived,
    -- then holds BVALID until BREADY.  This supports AXI4-Lite backpressure.
    signal aw_seen : std_logic := '0';
    signal w_seen  : std_logic := '0';

    signal awaddr_reg  : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal wdata_reg   : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal wstrb_reg   : std_logic_vector(STROBE_WIDTH-1 downto 0) := (others => '0');

    signal awready : std_logic;
    signal wready  : std_logic;
    signal bvalid  : std_logic := '0';
    signal bresp   : std_logic_vector(1 downto 0) := (others => '0');

    signal write_address_reg : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal write_data_reg    : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal write_strobe_reg  : std_logic_vector(STROBE_WIDTH-1 downto 0) := (others => '0');
    signal write_enable_reg  : std_logic := '0';

begin

    --------------------------------------------------------------------------
    -- AXI output mapping
    --------------------------------------------------------------------------
    SAXI_AWREADY <= awready;
    SAXI_WREADY  <= wready;
    SAXI_BRESP   <= bresp;
    SAXI_BVALID  <= bvalid;

    SAXI_ARREADY <= arready;
    SAXI_RDATA   <= rdata;
    SAXI_RRESP   <= rresp;
    SAXI_RVALID  <= rvalid;

    read_address  <= read_address_reg;
    read_enable   <= read_enable_reg;
    write_address <= write_address_reg;
    write_enable  <= write_enable_reg;
    write_data    <= write_data_reg;
    write_strobe  <= write_strobe_reg;

    clk    <= SAXI_ACLK;
    resetn <= SAXI_ARESETN;

    bresp <= (others => '0');
    rresp <= (others => '0');

    -- Ready is high only when this one-deep AXI4-Lite slave can accept the
    -- corresponding channel.  No new write is accepted while a write response
    -- is waiting to be accepted.
    awready <= '1' when (SAXI_ARESETN = '1' and aw_seen = '0' and bvalid = '0') else '0';
    wready  <= '1' when (SAXI_ARESETN = '1' and w_seen  = '0' and bvalid = '0') else '0';

    --------------------------------------------------------------------------
    -- Robust AXI4-Lite read channel
    --
    -- 1. Accept AR when idle.
    -- 2. Present read_address/read_enable to the subordinate for one cycle.
    -- 3. Capture read_data into an AXI RDATA register.
    -- 4. Hold RVALID and RDATA stable until RREADY is asserted.
    --------------------------------------------------------------------------
    process(SAXI_ACLK)
    begin
        if rising_edge(SAXI_ACLK) then
            if SAXI_ARESETN = '0' then
                rd_state <= RD_IDLE;
                arready <= '1';
                rvalid <= '0';
                rdata <= (others => '0');
                read_address_reg <= (others => '0');
                read_enable_reg <= '0';
            else
                read_enable_reg <= '0';

                case rd_state is
                    when RD_IDLE =>
                        arready <= '1';
                        rvalid <= '0';

                        if SAXI_ARVALID = '1' and arready = '1' then
                            read_address_reg <= local_read_addr;
                            read_enable_reg <= '1';
                            arready <= '0';
                            rd_state <= RD_CAPTURE;
                        end if;

                    when RD_CAPTURE =>
                        -- read_data is now based on the read_address_reg that
                        -- was presented during the previous cycle.
                        rdata <= read_data;
                        rvalid <= '1';
                        arready <= '0';
                        rd_state <= RD_RESP;

                    when RD_RESP =>
                        arready <= '0';

                        if SAXI_RREADY = '1' then
                            rvalid <= '0';
                            arready <= '1';
                            rd_state <= RD_IDLE;
                        else
                            -- Hold RVALID/RDATA stable while the AXI master is
                            -- applying read-channel backpressure.
                            rvalid <= '1';
                        end if;

                    when others =>
                        rd_state <= RD_IDLE;
                        arready <= '1';
                        rvalid <= '0';
                end case;
            end if;
        end if;
    end process;

    --------------------------------------------------------------------------
    -- Robust AXI4-Lite write channel
    --
    -- AW and W may arrive in either order.  When both have arrived, generate a
    -- one-cycle subordinate write_enable pulse and hold BVALID until BREADY.
    --------------------------------------------------------------------------
    process(SAXI_ACLK)
        variable next_aw_seen : std_logic;
        variable next_w_seen  : std_logic;
        variable next_awaddr  : std_logic_vector(ADDR_WIDTH-1 downto 0);
        variable next_wdata   : std_logic_vector(DATA_WIDTH-1 downto 0);
        variable next_wstrb   : std_logic_vector(STROBE_WIDTH-1 downto 0);
    begin
        if rising_edge(SAXI_ACLK) then
            if SAXI_ARESETN = '0' then
                aw_seen <= '0';
                w_seen <= '0';
                awaddr_reg <= (others => '0');
                wdata_reg <= (others => '0');
                wstrb_reg <= (others => '0');
                write_address_reg <= (others => '0');
                write_data_reg <= (others => '0');
                write_strobe_reg <= (others => '0');
                write_enable_reg <= '0';
                bvalid <= '0';
            else
                write_enable_reg <= '0';

                -- Complete an outstanding write response only when accepted.
                if bvalid = '1' then
                    if SAXI_BREADY = '1' then
                        bvalid <= '0';
                    end if;
                else
                    next_aw_seen := aw_seen;
                    next_w_seen  := w_seen;
                    next_awaddr  := awaddr_reg;
                    next_wdata   := wdata_reg;
                    next_wstrb   := wstrb_reg;

                    if SAXI_AWVALID = '1' and awready = '1' then
                        next_aw_seen := '1';
                        next_awaddr := local_write_addr;
                    end if;

                    if SAXI_WVALID = '1' and wready = '1' then
                        next_w_seen := '1';
                        next_wdata := SAXI_WDATA;

                        if USE_WRITE_STROBES then
                            next_wstrb := SAXI_WSTRB;
                        else
                            next_wstrb := (others => '1');
                        end if;
                    end if;

                    if next_aw_seen = '1' and next_w_seen = '1' then
                        write_address_reg <= next_awaddr;
                        write_data_reg <= next_wdata;
                        write_strobe_reg <= next_wstrb;
                        write_enable_reg <= '1';
                        bvalid <= '1';

                        next_aw_seen := '0';
                        next_w_seen := '0';
                    end if;

                    aw_seen <= next_aw_seen;
                    w_seen <= next_w_seen;
                    awaddr_reg <= next_awaddr;
                    wdata_reg <= next_wdata;
                    wstrb_reg <= next_wstrb;
                end if;
            end if;
        end if;
    end process;

end arch_imp;
