AXI4-Lite to SPI updated VHDL files

Compile order:
1. axi4_lite_interface_v1_0.vhd
2. spi_peripheral.vhd
3. axi_spi_simple.vhd
4. tb_axi_spi_simple.vhd

Changes made:
- axi4_lite_interface_v1_0.vhd:
  Fixed multiple drivers on read_enable by making the combinational read-control
  process drive sig_read_enable, then assigning read_enable <= sig_read_enable.

- spi_peripheral.vhd:
  Fixed typo in the control-register write case. The high-byte write now clears
  reg2(31 downto 24), not reg3(31 downto 24).

- axi_spi_simple.vhd:
  Kept functionally the same, but cleaned formatting and made the component
  declaration match the generic AXI read-data width.

- tb_axi_spi_simple.vhd:
  Added self-checking AXI4-Lite/SPI loopback testbench.
